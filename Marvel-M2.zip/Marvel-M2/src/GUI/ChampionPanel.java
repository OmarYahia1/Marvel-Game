package GUI;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class ChampionPanel extends JPanel implements ActionListener, ItemListener{
	
	private MainFrame mainframe;
	private JComboBox<String> c1;
	private JComboBox<String> c2;
	private JComboBox<String> c3;
	private JComboBox<String> c4;
	private JComboBox<String> c5;
	private JComboBox<String> c6;
	private JButton button;
	private JLabel label1;
	private JLabel label2;
	private JComboBox<String> leader1;
	private JComboBox<String> leader2;
	private JTextArea text;
	private JLabel l1;
	private JLabel l2;
	private JLabel l3;
	private JLabel l4;
	private JLabel l5;
	private JLabel l6;
	
	public ChampionPanel(MainFrame mainframe)
	{
		this.mainframe = mainframe;
		this.setLayout(null);
		c1 = new JComboBox<String>(mainframe.champions());
		c1.setBounds(200,100,200,30);
		c1.addItemListener(this);
		this.add(c1);
		c2 = new JComboBox<String>(mainframe.champions());
		c2.setBounds(200,150,200,30);
		c2.addItemListener(this);
		this.add(c2);
		c3 = new JComboBox<String>(mainframe.champions());
		c3.setBounds(200,200,200,30);
		c3.addItemListener(this);
		this.add(c3);
		c4 = new JComboBox<String>(mainframe.champions());
		c4.setBounds(550,100,200,30);
		c4.addItemListener(this);
		this.add(c4);
		c5 = new JComboBox<String>(mainframe.champions());
		c5.setBounds(550,150,200,30);
		c5.addItemListener(this);
		this.add(c5);
		c6 = new JComboBox<String>(mainframe.champions());
		c6.setBounds(550,200,200,30);
		c6.addItemListener(this);
		this.add(c6);
		label1 = new JLabel("First Player");
		label1.setBounds(200,50,200,40);
		label1.setFont(new Font("Yorktown",Font.BOLD,25));
		this.add(label1);
		label2 = new JLabel("Second Player");
		label2.setBounds(550,50,200,40);
		label2.setFont(new Font("Yorktown",Font.BOLD,25));
		this.add(label2);
		button = new JButton("Start Game");
		button.setBounds(400,550,200,60);
		button.setFocusable(false);
		button.setFont(new Font("Yorktown",Font.BOLD,25));
		button.setForeground(Color.WHITE);
		button.setBackground(Color.BLACK);
		button.addActionListener(this);
		this.add(button);
		leader1 = new JComboBox<String>(mainframe.fisrtLeader());
		leader1.setBounds(200,250,200,30);
		leader1.addItemListener(this);
		this.add(leader1);
		leader2 = new JComboBox<String>(mainframe.secondLeader());
		leader2.setBounds(550,250,200,30);
		leader2.addItemListener(this);
		this.add(leader2);
		text = new JTextArea();
		text.setBounds(200,300,550,230);
		text.setEditable(false);
		this.add(text);
		l1 = new JLabel("Champion 1");
		l1.setBounds(100,95,100,40);
		l1.setFont(new Font("Yorktown",Font.BOLD,15));
		this.add(l1);
		l2 = new JLabel("Champion 2");
		l2.setBounds(100,145,100,40);
		l2.setFont(new Font("Yorktown",Font.BOLD,15));
		this.add(l2);
		l3 = new JLabel("Champion 3");
		l3.setBounds(100,195,100,40);
		l3.setFont(new Font("Yorktown",Font.BOLD,15));
		this.add(l3);
		l4 = new JLabel("Champion 1");
		l4.setBounds(450,95,100,40);
		l4.setFont(new Font("Yorktown",Font.BOLD,15));
		this.add(l4);
		l5 = new JLabel("Champion 2");
		l5.setBounds(450,145,100,40);
		l5.setFont(new Font("Yorktown",Font.BOLD,15));
		this.add(l5);
		l6 = new JLabel("Champion 3");
		l6.setBounds(450,195,100,40);
		l6.setFont(new Font("Yorktown",Font.BOLD,15));
		this.add(l6);
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		if(c1.getSelectedIndex()==c2.getSelectedIndex() || c1.getSelectedIndex()==c3.getSelectedIndex()
				|| c1.getSelectedIndex()==c4.getSelectedIndex() || c1.getSelectedIndex()==c5.getSelectedIndex()
				|| c1.getSelectedIndex()==c6.getSelectedIndex() || c2.getSelectedIndex()==c3.getSelectedIndex()
				|| c2.getSelectedIndex()==c4.getSelectedIndex() || c2.getSelectedIndex()==c5.getSelectedIndex()
				|| c2.getSelectedIndex()==c6.getSelectedIndex()|| c3.getSelectedIndex()==c4.getSelectedIndex()
				|| c3.getSelectedIndex()==c5.getSelectedIndex() || c3.getSelectedIndex()==c6.getSelectedIndex()
				|| c4.getSelectedIndex()==c5.getSelectedIndex() || c4.getSelectedIndex()==c6.getSelectedIndex()
				||c5.getSelectedIndex()==c6.getSelectedIndex())
		{
			JOptionPane.showMessageDialog(this,"Champions should be different", "Error",JOptionPane.ERROR_MESSAGE);
		}
		else if (leader1.getSelectedIndex()==0)
			JOptionPane.showMessageDialog(this,"First player should choose a leader", "Error",JOptionPane.ERROR_MESSAGE);
		else if(leader2.getSelectedIndex()==0)
			JOptionPane.showMessageDialog(this,"Second player should choose a leader", "Error",JOptionPane.ERROR_MESSAGE);
		else
		
			mainframe.goToGamePanel(c1.getSelectedIndex(),c2.getSelectedIndex(),c3.getSelectedIndex(),c4.getSelectedIndex(),
					c5.getSelectedIndex(),c6.getSelectedIndex(),leader1.getSelectedIndex(),leader2.getSelectedIndex());
		
		
	}


	@Override
	public void itemStateChanged(ItemEvent e) {
		if(e.getSource()==c1)
		{
			text.setText(mainframe.info(c1.getSelectedIndex()));
		}
		else if(e.getSource()==c2)
		{
			text.setText(mainframe.info(c2.getSelectedIndex()));
		}
		else if(e.getSource()==c3)
		{
			text.setText(mainframe.info(c3.getSelectedIndex()));
		}
		else if(e.getSource()==c4)
		{
			text.setText(mainframe.info(c4.getSelectedIndex()));
		}
		else if(e.getSource()==c5)
		{
			text.setText(mainframe.info(c5.getSelectedIndex()));
		}
		else if(e.getSource()==c6)
		{
			text.setText(mainframe.info(c6.getSelectedIndex()));
		}
	}
	
	
}