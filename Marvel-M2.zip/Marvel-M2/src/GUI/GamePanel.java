package GUI;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import engine.PriorityQueue;
import exceptions.AbilityUseException;
import exceptions.ChampionDisarmedException;
import exceptions.InvalidTargetException;
import exceptions.LeaderAbilityAlreadyUsedException;
import exceptions.LeaderNotCurrentException;
import exceptions.NotEnoughResourcesException;
import exceptions.UnallowedMovementException;
import model.abilities.Ability;
import model.abilities.AreaOfEffect;
import model.abilities.CrowdControlAbility;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.effects.Effect;
import model.world.AntiHero;
import model.world.Champion;
import model.world.Cover;
import model.world.Direction;
import model.world.Hero;

public class GamePanel extends JPanel implements ActionListener{
	
	private MainFrame mainframe;
	private JPanel boardPanel;
	private JButton[][] boardButton;
	private JPanel actionPanel;
	private JButton up;
	private JButton down;
	private JButton right;
	private JButton left;
	private JButton m;
	private JButton a;
	private JButton cast;
	private JButton end;
	private JLabel l1;
	private JLabel l2;
	private JComboBox<String>c4;
	private JTextArea text;
	private JButton leader;
	private Direction d;
	private JTextField t1;
	private JTextField t2;
	private JTextArea text2;
	private JLabel xcast;
	private JLabel ycast;
	private JLabel u1;
	private JLabel u2;
	private JButton turn;
	
	public GamePanel(MainFrame mainframe)
	{
		this.mainframe = mainframe;
		this.setLayout(null);
		boardPanel = new JPanel();
		boardPanel.setLayout(new GridLayout(5,5));
		this.add(boardPanel);
		boardPanel.setBounds(10,10,800,550);
		boardButton = new JButton[5][5];
		for(int i=0; i<5;i++)
		{
			for(int j=0;j<5;j++)
			{
				boardButton[i][j]= new JButton();
				boardButton[i][j].addActionListener(this);
				boardButton[i][j].setFocusable(false);
				boardPanel.add(boardButton[i][j]);
			}
		}
		actionPanel = new JPanel();
		actionPanel.setBounds(800,10,600,1400);
		actionPanel.setLayout(null);
		this.add(actionPanel);
		up = new JButton("↑");
		up.setBounds(250,600,50,50);
		up.addActionListener(this);
		up.setFocusable(false);
		actionPanel.add(up);
		down = new JButton("↓");
		down.setBounds(250,500,50,50);
		down.addActionListener(this);
		down.setFocusable(false);
		actionPanel.add(down);
		right = new JButton("→");
		right.setBounds(300,550,50,50);
		right.addActionListener(this);
		right.setFocusable(false);
		actionPanel.add(right);
		left = new JButton("←");
		left.setBounds(200,550,50,50);
		left.setFocusable(false);
		left.addActionListener(this);
		actionPanel.add(left);
		m = new JButton("Move");
		m.setBounds(400,500,100,50);
		m.setFocusable(false);
		m.addActionListener(this);
		actionPanel.add(m);
		a = new JButton("Attack");
		a.setFocusable(false);
		a.setBounds(400,600,100,50);
		a.addActionListener(this);
		actionPanel.add(a);
		cast = new JButton("Cast");
		cast.setBounds(30,500,150,50);
		cast.setFocusable(false);
		cast.addActionListener(this);
		actionPanel.add(cast);
		end = new JButton("End turn");
		end.setBounds(30,600,150,50);
		end.setFocusable(false);
		end.addActionListener(this);
		actionPanel.add(end);
		l1 = new JLabel("First Player: "+  mainframe.getGame().getFirstPlayer().getName());
		l1.setFont(new Font("Yorktown",Font.BOLD,25));
		l1.setBounds(30,0,400,100);
		actionPanel.add(l1);
		l2 = new JLabel("Second Player: "+ mainframe.getGame().getSecondPlayer().getName());
		l2.setBounds(30,70,400,100);
		l2.setFont(new Font("Yorktown",Font.BOLD,25));
		actionPanel.add(l2);
		c4=new JComboBox<String>();
		c4.setBounds(30,370,470,50);
		actionPanel.add(c4);
		text = new JTextArea();
		JScrollPane sp = new JScrollPane(text);
		sp.setBounds(30,150,235,200);
		actionPanel.add(sp);
		text2 = new JTextArea();
		JScrollPane sp2 = new JScrollPane(text2);
		sp2.setBounds(270,150,235,200);
		actionPanel.add(sp2);
		leader = new JButton("Leader Ability");
		leader.setBounds(30,430,470,50);
		leader.setFocusable(false);
		leader.addActionListener(this);
		actionPanel.add(leader);
		t1 = new JTextField();
		t2 = new JTextField();
		t1.setBounds(470,55,50,20);
		actionPanel.add(t1);
		t2.setBounds(470,75,50,20);
		actionPanel.add(t2);
		text.setText(infoTwo((Champion)(mainframe.getGame().getCurrentChampion())));
		xcast = new JLabel("x for cast ability");
		ycast = new JLabel("y for cast ability");
		xcast.setBounds(350,50,120,30);
		xcast.setFont(new Font("Yorktown",Font.BOLD,15));
		actionPanel.add(xcast);
		ycast.setBounds(350,70,120,30);
		ycast.setFont(new Font("Yorktown",Font.BOLD,15));
		actionPanel.add(ycast);
		u1 = new JLabel();
		u1.setBounds(80,560,300,40);
		u1.setFont(new Font("Yorktown",Font.BOLD,15));
		this.add(u1);
		u2 = new JLabel();
		u2.setFont(new Font("Yorktown",Font.BOLD,15));
		u2.setBounds(400, 560,300,40);
		this.add(u2);
		turn = new JButton("Turn Order");
		turn.setBounds(30,600,100,40);
		turn.addActionListener(this);
		turn.setFocusable(false);
		this.add(turn);
		update();
	}
	public void update()
	{
		for(int i=0; i<5;i++)
		{
			for(int j=0;j<5;j++)
			{
				if(mainframe.getGame().getBoard()[i][j] instanceof Champion)
				{
					if((Champion)mainframe.getGame().getBoard()[i][j]==mainframe.getGame().getCurrentChampion())
					{
						boardButton[i][j].setBackground(Color.GREEN);
						boardButton[i][j].setForeground(Color.WHITE);
					}
					else if(isfromFirstTeam((Champion)(mainframe.getGame().getBoard()[i][j]))==1)
					{
						boardButton[i][j].setBackground(Color.BLUE);
						boardButton[i][j].setForeground(Color.WHITE);
					}
					else if(isfromFirstTeam((Champion)(mainframe.getGame().getBoard()[i][j]))==0)
					{
						boardButton[i][j].setBackground(Color.RED);
						boardButton[i][j].setForeground(Color.WHITE);
					}
					boardButton[i][j].setText(((Champion)(mainframe.getGame().getBoard()[i][j])).getName()+ " "+ ((Champion)(mainframe.getGame().getBoard()[i][j])).getCurrentHP());
				}
			
				
				
				else if(mainframe.getGame().getBoard()[i][j] instanceof Cover)
				{
					boardButton[i][j].setBackground(Color.BLACK);
					boardButton[i][j].setForeground(Color.WHITE);
					boardButton[i][j].setText(((Cover)(mainframe.getGame().getBoard()[i][j])).getCurrentHP()+" ");
				}
				else
				{
					boardButton[i][j].setBackground(Color.WHITE);
					boardButton[i][j].setText("");
				}
				
			}
		}
		if(mainframe.getGame().isFirstLeaderAbilityUsed()==false)
		{
			u1.setText("First Player's Leader Ability is not used");
		}
		else {
			u1.setText("First Player's Leader Ability is used");
		}
		if(mainframe.getGame().isSecondLeaderAbilityUsed()==false)
		{
			u2.setText("Second Player's Leader Ability is not used");
		}
		else {
			u2.setText("Second Player's Leader Ability is  used");
		}
	c4.removeAllItems();
	Champion c=mainframe.getGame().getCurrentChampion();
	for(Ability h:c.getAbilities()) {
     c4.addItem(h.getName());	
	}
	this.revalidate();
	this.repaint();
}
	public String infoTwo(Champion c)
	{
		String s="";
		s+= "Champion name: " + c.getName()+"\n"+"Current HP: "+ c.getCurrentHP()+"\n"+"Mana: "+c.getMana()+"\n"+"ActionPoints: "+c.getCurrentActionPoints()+"\n"+"Attack Damage: "+c.getAttackDamage()+"\n"+"Attack Range: "+c.getAttackRange()+"\n";
		if(c instanceof Hero)
		{
			s+= "Champion Type: Hero"+"\n";
		}
		else if(c instanceof AntiHero)
		{
			s+= "Champion Type: AntiHero"+"\n";
		}
		else
			s+="Champion Type: Villain"+"\n";
		for(Ability a: c.getAbilities())
		{
			s+= "Ability: "+"\n"+"Ability name: "+a.getName()+"\n"+"Mana: "+a.getManaCost()+"\n"+"Area of effect: "+a.getCastArea()+"\n"+"Current cooldown: "+a.getCurrentCooldown()+
					"\n"+"Action costs: "+a.getRequiredActionPoints()+"\n"+"Cast Range: "+a.getCastRange()+"\n"+"Base cooldown: "+a.getBaseCooldown()+"\n";
			if(a instanceof DamagingAbility)
			{
				s+= "Type : DamagingAbility"+"\n"+"Damage Amount: "+((DamagingAbility) a).getDamageAmount()+"\n";
			}
			else if(a instanceof HealingAbility)
			{
				s+= "Type : Healing Ability"+"\n"+"Heal Amount: "+((HealingAbility) a).getHealAmount()+"\n";
			}
			else {
				s+= "Type : CrowdControlAbility"+"\n"+"Effect: "+((CrowdControlAbility) a).getEffect().getType()+"\n";
			}
		}
		for(Effect e: c.getAppliedEffects())
		{
			s+= "EFfects: "+"\n"+"Effect name: "+e.getName()+"\n"+"Duration: "+e.getDuration();
		}
		return s;
	}
	
	public int isfromFirstTeam(Champion c )
	{
		if(mainframe.getGame().getFirstPlayer().getTeam().contains(c))
		{
			return 1;
		}
		return 0;
	}
	public String RemainInfo(Champion c)
	{
		String s="";
		if(c!=(Champion)(mainframe.getGame().getCurrentChampion()))
		{
			s+= "Champion Name: "+c.getName()+"\n"+"Current HP: "+c.getCurrentHP()+"\n"+"Mana: "+c.getMana()+"\n"
					+"Speed: "+c.getSpeed()+"\n"+"Max actions per turn: "+c.getMaxActionPointsPerTurn()+"\n"+
					"Attack Damage: "+c.getAttackDamage()+"\n"+"Attack Range: "+c.getAttackRange()+"\n";
			if(c instanceof Hero)
			{
				s+="Champion Type: Hero"+"\n";
			}
			else if(c instanceof AntiHero)
			{
				s+="Champion Type: AntiHero"+"\n";
			}
			else
			{
				s+="Champion Type: Villain"+"\n";
			}
			if(isfromFirstTeam(c)==1)
			{
				if(mainframe.getGame().getFirstPlayer().getLeader()==c)
				{
					s+="The Champion is a Leader"+"\n";
				}
				else {
					s+="The Champion is not a Leader"+"\n";
				}
			}
			else {
				if(mainframe.getGame().getSecondPlayer().getLeader()==c)
				{
					s+="The Champion is a Leader"+"\n";
				}
				else {
					s+="The Champion is not a Leader"+"\n";
				}
			}
			for(Effect e: c.getAppliedEffects())
			{
				s+= "EFfects: "+"\n"+"Effect name: "+e.getName()+"\n"+"Duration: "+e.getDuration();
			}

		}
		return s;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		text.setText(infoTwo((Champion)(mainframe.getGame().getCurrentChampion())));
		if(e.getSource()==up)
		{
			d = Direction.UP;
		}
		if (e.getSource()==down)
		{
			d = Direction.DOWN;
		}
		if(e.getSource()==right)
		{
			d = Direction.RIGHT;
		}
		if(e.getSource()==left)
		{
			d = Direction.LEFT;
		}
		if(e.getSource()== a)
		{
			try {
				mainframe.getGame().attack(d);
				update();
			}
			catch(NotEnoughResourcesException |ChampionDisarmedException | InvalidTargetException f) {
				JOptionPane.showMessageDialog(this,f.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
			}
		}
		if(e.getSource()==m)
		{
			try {
				mainframe.getGame().move(d);
				update();
			}
			catch(NotEnoughResourcesException|UnallowedMovementException f) {
				JOptionPane.showMessageDialog(this,f.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
			}
		}
		if(e.getSource()==cast)
		{
			Ability a = mainframe.getGame().getCurrentChampion().getAbilities().get(c4.getSelectedIndex());
			try {
				if(a.getCastArea() == AreaOfEffect.DIRECTIONAL)
				{
					mainframe.getGame().castAbility(a, d);
				}
				else if (a.getCastArea() == AreaOfEffect.SINGLETARGET)
				{
					if(t1.getText().equals("") || t2.getText().equals(""))
					{
						JOptionPane.showMessageDialog(this,"You must choose a position in order to cast","Error", JOptionPane.ERROR_MESSAGE);
						return;
					}
					mainframe.getGame().castAbility(a,Integer.parseInt(t1.getText()),Integer.parseInt(t2.getText()));
				}
				else {
					mainframe.getGame().castAbility(a);
				}
				update();
			}
			catch (NotEnoughResourcesException |AbilityUseException |
					InvalidTargetException | CloneNotSupportedException f) {
				JOptionPane.showMessageDialog(this,f.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
			}
		}
		if(e.getSource()== end)
		{
			mainframe.getGame().endTurn();
			update();
			text.setText(infoTwo((Champion)(mainframe.getGame().getCurrentChampion())));
		}
		if(e.getSource()==leader)
		{
			try {
				mainframe.getGame().useLeaderAbility();
				update();
			}
			catch (LeaderNotCurrentException | LeaderAbilityAlreadyUsedException f) {
				JOptionPane.showMessageDialog(this,f.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
			}
		}
		if(mainframe.getGame().checkGameOver()!=null)
		{
			JOptionPane.showMessageDialog(this,"The WINNER is "+mainframe.getGame().checkGameOver().getName(),
					"GameOver",JOptionPane.INFORMATION_MESSAGE);
			mainframe.dispose();
		}
		for(int i=0;i<5;i++)
		{
			for(int j=0;j<5;j++)
			{
				if(e.getSource()==boardButton[i][j])
				{
					if(mainframe.getGame().getBoard()[i][j] instanceof Champion)
					{
						text2.setText(RemainInfo((Champion)(mainframe.getGame().getBoard()[i][j])));
					}
					
				}
			}
		}
		if(e.getSource()==turn)
		{
			PriorityQueue q = mainframe.getGame().getTurnOrder();
			Champion[] c = new Champion[q.size()];
			for(int i=0; !q.isEmpty();i++)
			{
				c[i]= (Champion)q.remove();
			}
			String s = "";
			for(int i = 0; i<c.length;i++)
			{
				if(i==c.length-1)
					s+= c[i].getName();
				else
					s+= c[i].getName()+" then ";
				q.insert(c[i]);
			}
			JOptionPane.showMessageDialog(this,s,"The Champion Turns",JOptionPane.INFORMATION_MESSAGE);
		}
		
		
	}
	

}