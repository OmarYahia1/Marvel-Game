package GUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

import engine.Game;
import engine.Player;
import model.world.Champion;

public class MainFrame extends JFrame implements ActionListener{
	
	private Game game;
	private NamePanel namePanel;
	private ChampionPanel championPanel;
	private String firstPlayerName;
	private String secondPlayerName;
	private GamePanel gamePanel; 
	
	public MainFrame()
	{
		namePanel = new NamePanel(this);
		this.getContentPane().add(namePanel);
		this.setTitle("Marvel");
		this.setSize(500,500);
		this.setVisible(true);
		//this.setResizable(false);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		//ImageIcon image = new ImageIcon("icon.png");
		//this.setIconImage(image.getImage());
		
	}
	public void goToChampionPanel(String s1, String s2)
	{
		firstPlayerName = s1;
		secondPlayerName = s2;
		
		try {
			Game.loadAbilities("Abilities.csv");
			Game.loadChampions("Champions.csv");
			this.setSize(1000,700);
			this.remove(namePanel);
			championPanel = new ChampionPanel(this);
			this.getContentPane().add(championPanel);
		} catch(IOException i) {
			i.printStackTrace();
		}
	}
	public String[] champions()
	{
		ArrayList<Champion> c = Game.getAvailableChampions();
		String[] s= new String[c.size()];
		for(int i =0;i<c.size();i++)
		{
			s[i]= c.get(i).getName();
		}
		return s;
	}
	public String[] fisrtLeader()
	{
		String[] s = new String[4];
		s[0]= "Select first player's Leader";
		s[1]= "Champion 1";
		s[2]= "Champion 2";
		s[3]= "Champion 3";
		return s;
	}
	public String[] secondLeader()
	{
		String[] s = new String[4];
		s[0]= "Select second player's Leader";
		s[1]= "Champion 1";
		s[2]= "Champion 2";
		s[3]= "Champion 3";
		return s;
	}
	public String info(int champ)
	{
		ArrayList<Champion> a = Game.getAvailableChampions();
		Champion c = a.get(champ);
		String s = "Champion Name: "+ c.getName()+"\n"+ "Attack Damage: "+c.getAttackDamage()+"\n"+ "Attack Range: "+c.getAttackRange()+
				"\n"+"CurrentHP: "+c.getCurrentHP()+"\n"+"Mana: "+c.getMana()+"\n"+"Abilities: ";
		for(int i=0;i<c.getAbilities().size();i++)
		{
			s+=c.getAbilities().get(i).getName()+"\n";
		}
		s+=c.getName()+"\n"+c.getAttackDamage()+"\n"+c.getAttackRange()+"\n"+c.getCurrentActionPoints()+"\n"
				+c.getCurrentHP()+"\n"+c.getMana()+"\n"+c.getMaxActionPointsPerTurn()+"\n"+c.getMaxHP()+
				"\n"+c.getSpeed();
		
		return s;
	}
	public void goToGamePanel(int a, int b, int c, int d, int e, int f, int leader1, int leader2)
	{
		this.remove(championPanel);
		this.setSize(2000,1500);
		Player first = new Player(firstPlayerName);
		Player second = new Player(secondPlayerName);
		first.getTeam().add(Game.getAvailableChampions().get(a));
		first.getTeam().add(Game.getAvailableChampions().get(b));
		first.getTeam().add(Game.getAvailableChampions().get(c));
		second.getTeam().add(Game.getAvailableChampions().get(d));
		second.getTeam().add(Game.getAvailableChampions().get(e));
		second.getTeam().add(Game.getAvailableChampions().get(f));
		if(leader1 == 1)
		{
			first.setLeader(Game.getAvailableChampions().get(a));
		}
		else if(leader1 ==2)
		{
			first.setLeader(Game.getAvailableChampions().get(b));
		}
		else if(leader1 == 3)
		{
			first.setLeader(Game.getAvailableChampions().get(c));
		}
		if(leader2 == 1)
		{
			second.setLeader(Game.getAvailableChampions().get(d));
		}
		else if(leader2 == 2)
		{
			second.setLeader(Game.getAvailableChampions().get(e));
		}
		else if(leader2 == 3)
		{
			second.setLeader(Game.getAvailableChampions().get(f));
		}
		game = new Game(first,second);
		gamePanel = new GamePanel(this);
		this.getContentPane().add(gamePanel);
		this.validate();
		this.repaint();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		
	}
	public static void main(String[]args)
	{
		MainFrame mainFrame = new MainFrame();
	}
	public Game getGame() {
		return game;
	}

}