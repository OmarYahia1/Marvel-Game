package GUI;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class NamePanel extends JPanel implements ActionListener
{
	private MainFrame mainFrame;
	private JLabel label1;
	private JLabel label2;
	private JTextField text1;
	private JTextField text2;
	private JButton button;
	//private JLabel label3;
	public NamePanel(MainFrame mainFrame)
	{
		this.mainFrame=mainFrame;
		this.setLayout(null);
		label1= new JLabel("Player 1");
		label2= new JLabel("Player 2");
		text1= new JTextField();
		text2= new JTextField();
		button = new JButton("NEXT");
	    label1.setBounds(220,170,100,25);
	    label1.setForeground(Color.BLACK);
	    label1.setFont(new Font("Yorktown",Font.BOLD,20));
	    this.add(label1);
	    text1.setBounds(160,200,200,30);
	    this.add(text1);
	    label2.setBounds(220,230,100,25);
	    label2.setForeground(Color.BLACK);
	    label2.setFont(new Font("Yorktown",Font.BOLD,20));
	    this.add(label2);
	    text2.setBounds(160,260,200,30);
	    this.add(text2);
	    button.setBounds(195,360,130,50);
	    button.addActionListener(this);
	    this.add(button);
	    button.setFocusable(false);
	    button.setFont(new Font("Yorktown",Font.BOLD,25));
	    button.setForeground(Color.WHITE);
	    button.setBackground(Color.BLACK);
	    //label3 = new JLabel();
	    //label3.setBounds(0,0,500,500);
	    //ImageIcon image = new ImageIcon("Avengers.png");
	    //label3.setIcon(image);
	    //this.add(label3);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(text1.getText().equals(""))
			JOptionPane.showMessageDialog(this,"Player 1 should enter a name", "Error",JOptionPane.ERROR_MESSAGE);
		else if(text2.getText().equals(""))
			JOptionPane.showMessageDialog(this,"Player 2 should enter a name", "Error",JOptionPane.ERROR_MESSAGE);
		else
		{
			mainFrame.goToChampionPanel(text1.getText(),text2.getText());
		}
	}

}